O esquema que vai matar a apresentação é mostrar que o **greedy só se baseia no cálculo de heurísticas**
diferente do A*, pois o A* diminui consideravelmente o número de caminhos usando um cálculo em g()
onde é calculado o **custo de atravessar esse caminho**.

Passo a Passo Apresentacao

Implementacao em Java, usando apenas a biblioteca swing para geracao gráfica.
Board 19x21, onde o layout para cada uma das 3 fases (explica o que difere as fases), mostra o array de string
